// EmploymentTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

/************************************************************************************************
FILE REPLICATION PROGRAM


DESCRIPTION:
	The file replication program is a console application that ensures that two 
	directory structures contain the same data (including sub directories). 
		
	Basic Functions:
		- (40 Points) - copies files from the source to destination if the destination's
						files are out of date / don't exist
		- (30 Points) - deletes old files on the destination that no longer exist on the source
		- (15 Points) - archives files on the destination machine before they are 
						deleted/replaced in an "archive" directory in the root of the destination
		- (15 Points) - maintains a log file which records replication activity (stores in archive directory)
			- contains statistics (x files on src, y files copied, z files deleted, time it took, etc)

	Arguments:
		-Src:  The source directory (absolute path)
		-Dest: The destination directory (absolute path)

NOTE: 
	- Complete what you can and as always, put quality before quantity!	
	- Don't be bashful, if you have a question or need clarification, ask!

RULES:
	Replication class cannot be pulled off the shelf (any "Helper" classes from the net must be approved)
	Must be written in C/C++
	
RESOURCES:
	- MSDN (Local on machine [in VS] or www.msdn.microsoft.com)
	- Any online resources (codeguru.com, devguru.com, programmersheaven.com, etc.)
	- Joe	
 
TIME LIMIT: None. Complete the test at your own pace, with the techniques that you are acustomed to.

HINTS:

- Useful Off-the-Shelf Classes & Functions:
	CFileFind (check MSDN...there are some VERY helpful examples)
	CFile
	CString
	CTime
	CopyFile
	ShellExecute
	CreateDirectory
	DeleteDirectory

- Use Project->Properties->Configuration Properties->Debug->CommandLine Arguments to set the source and destination directories
*/


int _tmain(int argc, _TCHAR* argv[])
{
	const char * Usage = 
		"EmploymentTest <source dir> <target dir>\n"
		"     Match the contents of <source dir> in <target dir>";
	
	// Double check the command line
	//
	if (3 != argc)
	{
		cout << "Invalid command line" << endl << Usage;
		return 1;
	}
	

	printf("Press ENTER to continue\n"); 
	getchar(); 
	return(1); 

	return 0;
}
